import Navbar from "./views/pages/navbar/Navbar";
import './style/nav.css'



function App() {
  return (
    <div className="App">
      <Navbar/>
    </div>
  );
}

export default App;
